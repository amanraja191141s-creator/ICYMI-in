# SA Calculator v98.36 — unified 18-screen premium UI

## Scope
- Added a unified visual layer across all 18 existing core screens (Calculator, 16 dedicated tools, Settings).
- Preserved all existing screen IDs, calculation handlers, input semantics, currency providers, localization, history, favorites, themes and navigation.
- Improved card rhythm, field sizing, touch targets, result readability, narrow-screen spacing and reduced-motion behavior.
- Added a source-grounded 18-screen visual reference collage and machine-readable screen inventory.
- Added the new stylesheet to the service-worker asset list and Android workflow required-file gate.

## Exact inventory
`calc`, `currencies`, `units`, `discount`, `percent`, `salestax`, `bodymetrics`, `date`, `fuelcost`, `fuelefficiency`, `gradeavg`, `hex`, `loan`, `savings`, `tip`, `unitprice`, `worldtime`, `settings`.

## Release identity
- App version: `1.98.36-v98.36`
- Android versionCode: `1098036`

## Validation boundary
Automated source tests, syntax, web bundle and YAML validation are run for this package. APK generation on hosted Android CI and physical-device interaction/visual validation remain separate release checks.
