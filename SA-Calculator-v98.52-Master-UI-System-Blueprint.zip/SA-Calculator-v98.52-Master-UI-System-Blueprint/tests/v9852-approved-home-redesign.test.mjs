import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = p => fs.readFileSync(path.join(root,p),'utf8');

test('v98.52 app identity and CSS source layer are synchronized',()=>{
  const pkg=JSON.parse(read('package.json'));
  const html=read('index.html');
  const js=read('assets/js/app.js');
  const manifest=JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version,'1.98.52-v98.52');
  assert.match(html,/sa-build-version" content="1\.98\.52-v98\.52/);
  assert.match(html,/rebuild-v98\.52\.css/);
  assert.match(js,/const APP_VERSION = '1\.98\.52-v98\.52'/);
  assert.equal(manifest.version,pkg.version);
});

test('approved Home header exposes drawer, History, and overflow controls',()=>{
  const html=read('index.html');
  assert.match(html,/id="btn-drawer-open"/);
  assert.match(html,/id="btn-header-history"/);
  assert.match(html,/id="btn-tools-more"/);
  assert.match(html,/data-bottom-nav="calc"[^>]*>[\s\S]*?<span>Home<\/span>/);
});

test('Home keypad keeps existing calculation action contract and zero spans two columns',()=>{
  const html=read('index.html');
  const home=html.match(/<div class="screen active" id="screen-calc">([\s\S]*?)<\/div>\s*<section class="screen scientific-screen"/)[1];
  for (const key of ['C','±','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','=']) assert.ok(home.includes(`data-calc="${key}"`),`missing ${key}`);
  const css=read('assets/css/rebuild-v98.52.css');
  assert.match(css,/\.key-btn\.zero-key\{grid-column:span 2\}/);
  assert.match(css,/min-width:48px!important;min-height:48px!important/);
  assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css,/grid-template-rows:repeat\(5,minmax\(48px,1fr\)\)/);
});

test('header History action opens existing History modal without changing calculator handlers',()=>{
  const js=read('assets/js/app.js');
  assert.match(js,/getElementById\('btn-header-history'\)[\s\S]*?getElementById\('btn-history-open'\)\?\.click\(\)/);
  assert.match(js,/document\.getElementById\('btn-history-open'\)\.onclick = openHistoryModal/);
  assert.match(js,/data-calc/);
});

test('Android workflow selects exact v98.52 source and cache namespace',()=>{
  const wf=read('SA-Calculator-v98.52-Android-Workflow.yml');
  assert.match(wf,/1\.98\.52-v98\.52/);
  assert.match(wf,/1098052/);
  assert.match(wf,/rebuild-v98\.52\.css/);
  assert.match(wf,/sa-calculator-v98-52-home-screen-redesign-v9852/);
});
