import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.51 master blueprint covers every existing tool and core surface', () => {
  const inv = JSON.parse(read('design-reference/MASTER-SCREEN-INVENTORY-v98.51.json'));
  const html = read('index.html');
  assert.equal(inv.tools.length, 17);
  assert.deepEqual(inv.primary_navigation, ['calc','history','favorites','tools','settings']);
  for (const item of inv.tools) assert.ok(html.includes(`id="screen-${item.id}"`), `missing screen ${item.id}`);
  for (const id of ['calc','scientific','tools','favorites','settings']) assert.ok(html.includes(`id="screen-${id}"`), `missing core surface ${id}`);
  const blueprint = read('MASTER-UI-SYSTEM-BLUEPRINT-v98.51.md');
  for (const heading of ['## 3. Calculator home — Basic','## 4. Scientific Calculator','## 5. Tools catalogue','## 7. History','## 8. Favorites','## 9. Settings','## 10. Dialogs, pickers, menus and feedback','## 13. Regression and device test matrix']) assert.ok(blueprint.includes(heading), `missing ${heading}`);
});

test('v98.51 responsive master layer defines shared toolbar, navigation, tools, settings and keypad sizing', () => {
  const css = read('assets/css/rebuild-v98.51.css');
  for (const selector of ['.reference-screen-toolbar','.bottom-navigation','.premium-tool-card','#screen-settings .settings-row','#popup-keypad-sheet .popup-keypad-grid','#screen-viewport .calc-card']) assert.ok(css.includes(selector), `missing ${selector}`);
  assert.match(css, /min-height:48px/);
  assert.match(css, /@media\(max-width:360px\)/);
  assert.match(css, /@media\(min-width:600px\)/);
  assert.match(css, /prefers-reduced-motion/);
});

test('v98.51 package, runtime, bundle builder, service worker and Android workflow share exact identity', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const builder = read('scripts/prepare-android-web.mjs');
  const sw = read('service-worker.js');
  const wf = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.52-v98.52');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(app.includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(html, /rebuild-v98\.51\.css/);
  assert.match(builder, /rebuild-v98\.51\.css/);
  assert.match(sw, /sa-calculator-v98-52-home-screen-redesign-v9852/);
  assert.match(wf, /SA_EXPECTED_VERSION: '1\.98\.52-v98\.52'/);
  assert.match(wf, /1098052/);
  assert.equal(wf, read('SA-Calculator-v98.51-Android-Workflow.yml'));
});

test('tool keyboard contract keeps numeric keypad distinct from searchable unit/currency selectors', () => {
  const html = read('index.html');
  const blueprint = read('MASTER-UI-SYSTEM-BLUEPRINT-v98.51.md');
  assert.match(html, /id="cur-from"/);
  assert.match(html, /id="unit-from"/);
  assert.match(blueprint, /The keypad is numeric only; never render all currency country names or unit names among digit keys/);
  assert.match(blueprint, /Base-aware keypad/);
  assert.match(blueprint, /native date picker/);
});


test('tool toolbar Back returns to the originating top-level destination and Browse Tools is a real action', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /topLevelScreens\.has\(STATE\.currentScreen\)[\s\S]*?STATE\.previousScreen = STATE\.currentScreen/);
  assert.match(app, /back\.addEventListener\('click', \(\) => switchScreen\(STATE\.previousScreen \|\| 'calc'\)\)/);
  assert.match(app, /more\.setAttribute\('aria-label', 'Browse tools'\)/);
  assert.match(app, /more\.addEventListener\('click', \(\) => switchScreen\('tools'\)\)/);
});


test('tool navigation preserves the outgoing screen scroll offset for return navigation', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /screenScrollPositions: Object\.create\(null\)/);
  assert.match(app, /if \(outgoingScroll\) STATE\.screenScrollPositions\[STATE\.currentScreen\] = outgoingScroll\.scrollTop/);
  assert.match(app, /scrollContainer\.scrollTop = Math\.max\(0, Number\(STATE\.screenScrollPositions\[screenId\]\) \|\| 0\)/);
});
