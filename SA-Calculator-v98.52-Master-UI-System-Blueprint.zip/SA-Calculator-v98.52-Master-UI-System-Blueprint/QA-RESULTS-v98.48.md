# QA results — v98.48

- Automated Node test suite: **316 passed, 0 failed**.
- JavaScript syntax: `assets/js/app.js`, `service-worker.js`, and `scripts/prepare-android-web.mjs` passed `node --check`.
- Android web bundle: regenerated with 24 required assets and 14 CSS layers consolidated into one production stylesheet.
- Scientific layout regression: function bank scrolls independently; five numeric rows and memory controls have explicit reserved space.
- Scientific editor regression: unchanged input value is not reassigned during typing; programmatic edits move caret/scroll appropriately.
- Tools layout regression: search and category rows are non-shrinking; cards use a forced two-column grid with bounded labels.
- YAML: parsed successfully with PyYAML.
- ZIP: archive integrity checked after packaging.

Not verified in this workspace: hosted GitHub Actions APK build, physical Android installation, screenshots from the target phone, frame rate, touch latency, memory or battery measurements.

Dependency reproducibility note: `package-lock.json` could not be generated because the npm registry metadata is not cached in the offline build environment. Direct Capacitor dependencies remain exactly pinned in `package.json`; transitive dependency locking remains outstanding.
