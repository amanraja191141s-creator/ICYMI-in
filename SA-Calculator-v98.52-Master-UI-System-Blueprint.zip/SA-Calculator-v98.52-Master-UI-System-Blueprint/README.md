# SA Calculator v98.51 — Master UI System Blueprint

This release is based on the exact v98.50 source ZIP and introduces a complete, source-grounded master specification for the app shell, five-destination navigation, Basic and Scientific Calculator, all 17 tool cards, Settings, History, Favorites, keyboards, pickers, dialogs, responsive sizing, theme/localization, data behavior and regression gates.

## Main changes
- Added `MASTER-UI-SYSTEM-BLUEPRINT-v98.51.md` and `design-reference/MASTER-SCREEN-INVENTORY-v98.51.json`.
- Added final `assets/css/rebuild-v98.51.css` consistency layer for contextual tool toolbar, five-item navigation, Tools grid, tool forms, Settings, History, keypad sheet and responsive breakpoints.
- Preserved existing calculator/tool calculation handlers and storage models; no unsupported symbolic algebra, matrix, complex, calculus or graphing actions are falsely exposed.
- Updated package, manifest, app version, service-worker cache, web-bundle CSS list and exact-source Android workflow to v98.51.

## Build and test
- `npm test`
- `npm run build:web`
- Android debug APK build runs in the included GitHub Actions workflow.

## Release identity
- Package: `1.98.51-v98.51`
- Android versionCode: `1098051`
- Workflow: `.github/workflows/main.yml` and `SA-Calculator-v98.51-Android-Workflow.yml`

## Validation boundary
Source-level automated tests (334/334), JavaScript syntax, YAML parsing and web-bundle generation passed locally. Hosted Android SDK/Gradle build and physical-device screenshots/touch/performance testing remain required before claiming device-level release readiness.
