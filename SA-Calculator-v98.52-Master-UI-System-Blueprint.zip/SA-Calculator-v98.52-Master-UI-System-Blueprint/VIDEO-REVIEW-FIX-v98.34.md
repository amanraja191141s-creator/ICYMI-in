# SA Calculator v98.35 — Physical Video Review Fix

## Source reviewed
- User screen recording: `Screenrecording_20261117_145230.mp4` (109.19 seconds)
- Previous source: SA Calculator v98.33 Premium System Rebuild
- Previous Android workflow: v98.33

## Video-observed UI issues addressed
- Removed the hidden global app-header footprint on tool screens so it cannot leave a clipped remnant above the injected tool toolbar.
- Locked the tool toolbar to a fixed, opaque flex row and constrained the screen viewport/scroll area to prevent content painting into the toolbar region.
- Removed the nested outer border/background from the Sales Tax percentage suffix wrapper while preserving one clear input border around the editable rate.
- Constrained the currency selector trigger to its parent width and clipped overflow to prevent selector content from creating stray edges.
- Kept Quick Guide content independently scrollable while its Done footer remains fixed and reachable on compact screens.
- Preserved route switching scroll reset and added regression coverage for it.

## Regression verification
- `npm test`: 259 passed, 0 failed.
- `npm run build:web`: passed; all 12 required runtime assets verified and copied to `www/`.
- `node --check assets/js/app.js`: passed.
- Android workflow copies are synchronized byte-for-byte.
- Android package version: `1.98.36-v98.36`.
- Android versionCode: `1098036`.

## Validation boundary
The supplied recording and source archive were inspected and the web/source regression suite passed. A fresh APK build on GitHub Actions and physical-device verification after installing v98.35 are still required; no claim of zero lag or zero defects is made before those checks.
